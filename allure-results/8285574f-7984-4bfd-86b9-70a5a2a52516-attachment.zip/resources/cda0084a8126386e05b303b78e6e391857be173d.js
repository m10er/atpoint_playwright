

/*
$(document).ready(function () {
  // CONSULTING SWIPER
  let consultingSwiper = new Swiper(".consulting-swiper-wrapper", {
    wrapperClass: "consulting-swiper-list",
    slideClass: "consulting-swiper-item",
    navigation: {
      nextEl: "#nextConsulting",
      prevEl: "#prevConsulting",
    },
    slidesPerView: "auto",
    direction: "horizontal",
    spaceBetween: 0,
    speed: 500,
    freeMode: false,
    grabCursor: true,
  });

  // INFOMETEN SWIPER
  let infometenSwiper = new Swiper(".infometen-swiper-wrapper", {
    wrapperClass: "infometen-swiper-list",
    slideClass: "infometen-swiper-item",
    navigation: {
      nextEl: "#nextInfometen",
      prevEl: "#prevInfometen",
    },
    slidesPerView: "auto",
    direction: "horizontal",
    spaceBetween: 0,
    speed: 500,
    freeMode: false,
    grabCursor: true,
  });

  // WORKSHOPS SWIPER
  let workshopSwiper = new Swiper(".workshop-swiper-wrapper", {
    wrapperClass: "workshop-swiper-list",
    slideClass: "workshop-swiper-item",
    navigation: {
      nextEl: "#nextWorkshop",
      prevEl: "#prevWorkshop",
    },
    slidesPerView: "auto",
    direction: "horizontal",
    spaceBetween: 0,
    speed: 500,
    freeMode: false,
    grabCursor: true,
  });

  var accordion = (function () {
    var $accordion = $(".faq-collection-list");
    var $accordion_header = $accordion.find(".faq__header");
    var $accordion_item = $(".faq");

    // default settings
    var settings = {
      // animation speed
      speed: 400,

      // close all other accordion items if true
      oneOpen: false,
    };

    return {
      // pass configurable object literal
      init: function ($settings) {
        $accordion_header.on("click", function () {
          accordion.toggle($(this));
        });

        $.extend(settings, $settings);

        // ensure only one accordion is active if oneOpen is true
        if (settings.oneOpen && $(".faq.cc-open").length > 1) {
          $(".faq.cc-open:not(:first)").removeClass("cc-open");
        }

        // reveal the active accordion bodies
        $(".faq.cc-open").find("> .faq__body").show();
      },
      toggle: function ($this) {
        if (
          settings.oneOpen &&
          $this[0] !=
            $this
              .closest(".faq-collection-list")
              .find("> .faq.cc-open > .faq__header")[0]
        ) {
          $this
            .closest(".faq-collection-list")
            .find("> .faq")
            .removeClass("cc-open")
            .find(".faq__body")
            .slideUp();
        }

        // show/hide the clicked accordion item
        $this.closest(".faq").toggleClass("cc-open");
        $this.next().stop().slideToggle(settings.speed);
      },
    };
  })();

  accordion.init({ speed: 300, oneOpen: true });
});
*/
