function infometenName() {
  let infometenFullName = $("#infometenName").text();
  let firstName = infometenFullName.split(" ")[0];
  $(".js-infometen-name").text(firstName);
}


Weglot.on("languageChanged", function(newLang) {
  infometenName()
})
infometenName()



function combineServices() {

  $("[cb-combine-element=copy] .w-dyn-item").prependTo("[cb-combine-element=paste]")
  $("[cb-combine-element=copy]").remove()

  $.each(globalSwipers, function() {
    this.update()
  })
}

combineServices()



$(document).ready(function () {
  // SPLIT INFOMETEN NAME
  

  // WORKSHOPS SWIPER
  let workshopSwiper = new Swiper(".workshops-cms-swiper-wrapper", {
    wrapperClass: "workshops-cms-swiper-list",
    slideClass: "workshops-cms-swiper-item",
    navigation: {
      nextEl: "#nextWorkshop",
      prevEl: "#prevWorkshop",
    },
    slidesPerView: "auto",
    direction: "horizontal",
    spaceBetween: 0,
    speed: 500,
    freeMode: false,
    grabCursor: true,
  });

  // CONSULTING SWIPER
  let consultingSwiper = new Swiper(".consulting-cms-swiper-wrapper", {
    wrapperClass: "consulting-cms-swiper-list",
    slideClass: "consulting-cms-swiper-item",
    navigation: {
      nextEl: "#nextConsulting",
      prevEl: "#prevConsulting",
    },
    slidesPerView: "auto",
    direction: "horizontal",
    spaceBetween: 0,
    speed: 500,
    freeMode: false,
    grabCursor: true,
  });

  /// SHOW MORE POST
  $lis = $(".blog-cms-coll-item");
  min = 2;
  max = $lis.length;
  var visible = 6;

  function showUpToIndex(index) {
    $lis.hide();
    $lis.slice(0, index).show();
  }

  function disableButtons() {
    if (visible >= max) {
      visible = max;
      $("#showMorePost").hide();
    } else {
      $("#showMorePost").show();
    }
  }

  showUpToIndex(visible);
  disableButtons();

  $("#showMorePost").click(function (e) {
    e.preventDefault();
    visible = visible + 2;
    disableButtons();
    showUpToIndex(visible);
  });
  /// SHOW MORE POST END

  // INFOMETEN SWIPER
  let infometenSwiper = new Swiper(".infometen-swiper-wrapper", {
    wrapperClass: "infometen-swiper-list",
    slideClass: "infometen-swiper-item",
    navigation: {
      nextEl: "#nextInfometen",
      prevEl: "#prevInfometen",
    },
    slidesPerView: "auto",
    direction: "horizontal",
    spaceBetween: 0,
    speed: 500,
    freeMode: false,
    grabCursor: true,
  });
});




$(".utility__empty:visible").parents(".cms-box").remove()













