$("[cb-empty-element=indicator]").parents("[cb-empty-element=target]").remove()

$(".search_icon").click(function() {
  $(".search__trigger")[0].click()
})



$("[cb-html-element=target]").each(function() {
    $(this).html($(this).text())
})




/* Navigation */

$(window).scroll(function() {
  stickyNavToggle()
})

$(document).ready(function() {
    stickyNavToggle()
})


function stickyNavToggle() {
  if ($(window).scrollTop() > 0) {
    $("body").addClass("sticky-nav")
  } 
  else {
    $("body").removeClass("sticky-nav")
  }
}




function NavToggle(state) {
  var menu = $(".nav__menu")

  $(".nav__section").removeClass("nav-open")
  $("body").css("overflow", "visible")

  if (state === "open") {
    $(".nav__section").addClass("nav-open")
    $("body").css("overflow", "hidden")
  }
}


$(".nav__menu-button").click(function() {
  if ($(".nav__section").hasClass("nav-open")) {
    NavToggle("close")
    burgerLinesToggle("close")
  }
  else {
    NavToggle("open")
    burgerLinesToggle("open")
  }
})



function burgerLinesToggle(state) {
    var t = $(".nav__burger-line").eq(0)
    var b = $(".nav__burger-line").eq(1)

    if (state === "open") {
        t.css("transform", "translateY(3.25px) rotateZ(0deg)")
        b.css("transform", "translateY(-3.25px) rotateZ(0deg)")

        setTimeout(function() {
            t.css("transform", "translateY(3.25px) rotateZ(45deg)")
            b.css("transform", "translateY(-3.25px) rotateZ(-45deg)")
        }, 360)
    }
    else if (state === "close") {
        t.css("transform", "translateY(3.25px) rotateZ(0deg)")
        b.css("transform", "translateY(-3.25px) rotateZ(0deg)")

        setTimeout(function() {
            t.css("transform", "translateY(0px) rotateZ(0deg)")
            b.css("transform", "translateY(0px) rotateZ(0deg)")
        }, 360)
    }
}




/* Date Localisation */

function localizeDates() {
  $('[cb-locdate-element]').each(function(){
    if ($(this).attr("cb-locdate-state") === "lock") {return}

    var lang = $("html").attr("lang")

    moment.locale(lang)
      
    var current = $(this).html();
    var cdate = moment(current,'YYYY-MM-DD').format("Do MMM");

    $(this).html(cdate);
    $(this).attr("cb-locdate-state", "lock")
  });  
}

localizeDates()


window.fsAttributes = window.fsAttributes || [];
window.fsAttributes.push([
  'cmsload',
  (listInstances) => {
    const [listInstance] = listInstances;

    listInstance.on('renderitems', (renderedItems) => {
      localizeDates()
    });
  },
]);



/* Dark Mode */

function setCookie(name, value) {
  var date = new Date();
  date.setTime(date.getTime()+15724800000);
  document.cookie = name + "="+value+"; expires=" + date.toGMTString() + "; path=/";
}


function toggleDarkmode() {
  if ($("body").hasClass("dark-mode")) {
    setPageMode("light")
  }
  else {
    setPageMode("dark")
  }
}

function setPageMode(mode) {
  if (mode === "dark") {
    $("body").addClass("dark-mode")
    setCookie("pagemode", "dark")
  }
  else if (mode === "light") {
    $("body").removeClass("dark-mode")
    setCookie("pagemode", "light")
  }
}


$("[cb-darkmode-element=toggle]").click(function() {
  toggleDarkmode()
})




/* ===== POPUP FORM ===== */


changeRRPopup("close", $(".c-popup .c-popup-termin"))

$(document).ready(function () {
  $(".js-show-popup-rr").click(function (e) {
    e.preventDefault();

    if ($(".c-popup").hasClass("cc-active")) {
      changeRRPopup("close", $(".c-popup, .c-popup-termin"))

    } else {
      changeRRPopup("open", $(".c-popup"))
    }
  });

  $(".c-popup__close, .c-popup__overlay").click(function () {
    changeRRPopup("close", $(".c-popup, .c-popup-termin"))
  });

  $(".js-show-popup-termin").click(function(e) {
    e.preventDefault();

    changeRRPopup("open", $(".c-popup-termin"))
  })

  $("[cb-popup-trigger=consulting]").click(function(e) {
    e.preventDefault();

    changeRRPopup("open", $(".c-popup-termin"))
  })
});


function changeRRPopup(state, target) {
  var el = target

  if (state === "open") {
    $("body").css("overflow", "hidden")
    el.addClass("cc-active");
    setTimeout(function() {
      $(".c-popup__overlay, .c-popup__wrapper").addClass("cc-active");
    }, 10)
  }
  else {
    $(".c-popup__overlay, .c-popup__wrapper").removeClass("cc-active");
    setTimeout(function() {
      el.removeClass("cc-active");
      $("body").css("overflow", "visible")
    }, 400)
  }
}





/* Footer Year */

$("#footerYear").text(new Date().getFullYear());



/* Add all Swipers */


function swiperExceptions() {
  var w = window.innerWidth || document.documentElement.clientWidth

  if (w > 479) {
    $("[cb-swiper-exception=only-mobile]").removeAttr("cb-swiper-group")
  }
}

swiperExceptions()


var globalSwipers = []

function addSwipers() {
  var swiperNames = []

  $("[cb-swiper-group]").each(function() {
    var el = $(this)
    var group = el.attr("cb-swiper-group")
    var selector = "[cb-swiper-group=" + group + "]"

    if ($.inArray(group, swiperNames) !== -1) {
      console.log("Group named " + group + " already exists")
      return
    }

    swiperNames.push(group)

    var container = selector + ' [cb-swiper-element=container]'
    var prev = selector + ' [cb-swiper-element=prev]'
    var next = selector + ' [cb-swiper-element=next]'
    var controls = selector + ' [cb-swiper-element=controls]'


    var dummySwiper = new Swiper (container, {
      wrapperClass: 'w-dyn-items',
      slideClass: 'w-dyn-item',
      navigation: {
        prevEl: prev,
        nextEl: next,
        disabledClass: "cb-swiper-disabled",
      },
      slidesPerView: 'auto',
      direction: 'horizontal',
      spaceBetween: 0,
      speed: 400,
      watchOverflow: true,
      grabCursor: true,
      loop: false,
      on: {
        lock: function() {
          $(controls).addClass("cb-swiper-hidden")
        },
        unlock: function() {
          $(controls).removeClass("cb-swiper-hidden")
        }
      },
    })

    globalSwipers.push(dummySwiper)
  })
}

addSwipers()




/* Replace Text with CMS */

function cbTextReplace() {
  $("[cb-textreplace-content]").each(function() {
    var attr = $(this).attr("cb-textreplace-content")
    var content = $(this).text()

    $("body *:not(:has(*))").each(function() {
      $(this).html($(this).html().replace("{{"+attr+"}}", content))
    })
  })
}

Weglot.on("languageChanged", function(newLang) {
  cbTextReplace()
})


/* hide empty buttons */

$(".cta-section .c-button-text:empty").parent().remove()



/* FAQ */

$(".utility__empty").parents(".faq-section").remove()


function addFAQDropdown() {
  if (!$(".faq-section").length) {return}

  $(".faq-dd__wrapper.cb-dd-open").removeClass("cb-dd-open")

  $(".faq-dd__button").click(function() {
    faqToggleDropdown($(this).parent())
  })

  $(".faq-collection-wrapper").append('<div role="list" class="faq-collection-list w-dyn-items"></div>')
  $(".faq-dd__wrapper").slice(Math.ceil($(".faq-dd__wrapper").length / 2)).appendTo($(".faq-collection-list").eq(1))

  function faqToggleDropdown(parent) {
    var list = parent.find(".faq-dd__list")
    var content = parent.find(".faq-dd__content")

    var state = list.height() === 0

    list.css("height", content.outerHeight() + "px")

    setTimeout(function() {
      $(".faq-dd__list").css("height", "0px")
      $(".faq-dd__wrapper").removeClass("cb-dd-open")

      if (state) {
        list.css("height", content.outerHeight() + "px")
        parent.addClass("cb-dd-open")

        setTimeout(function() {
          if (content.outerHeight() === list.outerHeight()) {
            list.css("height", "auto")
          }
        }, 600)
      }  
    }, 10)
  }    
}


addFAQDropdown()



/* Language Switcher (just Visual) */


function setupLangSwitcher() {
  var supportsTouch = 'ontouchstart' in window || navigator.msMaxTouchPoints;

  $(".nav-lang__container").off()

  if (supportsTouch) {
    $(".nav-lang__container").click(function() {
      $(this).find(".nav-lang__wrapper").toggleClass("nav-lang__open")
    })

    $("body").click(function(e) {
      if (!$(e.target).parents(".nav-lang__container").length) {
        $(".nav-lang__wrapper").removeClass("nav-lang__open")
      }
    })
  }
  else {
    $(".nav-lang__container").hover(function() {
      $(this).find(".nav-lang__wrapper").addClass("nav-lang__open")
    }, function() {
      $(".nav-lang__wrapper").removeClass("nav-lang__open")
    })
  }
}

setupLangSwitcher()


$(".nav-lang__item").click(function(e) {
  if (e.currentTarget.className.includes("nav-lang__active")) {return}

  Weglot.switchTo($(this).attr("cb-lang-code"))

  setTimeout(function() {
    $(".nav-lang__wrapper").removeClass("nav-lang__open")
  }, 10)
})



Weglot.on("languageChanged", function(newLang) {
  $(".nav-lang__item").removeClass("nav-lang__active")
  $(".nav-lang__item[cb-lang-code="+newLang+"]").addClass("nav-lang__active")


  setLangPlural()
})



function setLangPlural() {
  if ($("html").attr("lang") === "de") {
    $("[cb-lang-element=plural]").text("e")
  }
  else {
    $("[cb-lang-element=plural]").text("s")
  }
}


setLangPlural()





