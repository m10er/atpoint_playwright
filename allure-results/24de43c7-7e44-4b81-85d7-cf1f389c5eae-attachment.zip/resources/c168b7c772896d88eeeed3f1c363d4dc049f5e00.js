$(".utility__empty:visible").parents(".cms-box").remove()

