$(".infometen").each(function() {
  $(this).find(".w-condition-invisible").remove();
});



$(document).ready(function () {
  

  $(".filter__btn__info").mouseover(function () {
    $(this)
      .closest(".filter__btn")
      .find(".filter__btn__tooltip")
      .addClass("cc-active");
  });
  $(".filter__btn__info").mouseleave(function () {
    $(".filter__btn__tooltip").removeClass("cc-active");
  });

  var accordion = (function () {
    var $accordion = $(".faq-collection-list");
    var $accordion_header = $accordion.find(".faq__header");
    var $accordion_item = $(".faq");

    // default settings
    var settings = {
      // animation speed
      speed: 400,

      // close all other accordion items if true
      oneOpen: false,
    };

    return {
      // pass configurable object literal
      init: function ($settings) {
        $accordion_header.on("click", function () {
          accordion.toggle($(this));
        });

        $.extend(settings, $settings);

        // ensure only one accordion is active if oneOpen is true
        if (settings.oneOpen && $(".faq.cc-open").length > 1) {
          $(".faq.cc-open:not(:first)").removeClass("cc-open");
        }

        // reveal the active accordion bodies
        $(".faq.cc-open").find("> .faq__body").show();
      },
      toggle: function ($this) {
        if (
          settings.oneOpen &&
          $this[0] !=
            $this
              .closest(".faq-collection-list")
              .find("> .faq.cc-open > .faq__header")[0]
        ) {
          $this
            .closest(".faq-collection-list")
            .find("> .faq")
            .removeClass("cc-open")
            .find(".faq__body")
            .slideUp();
        }

        // show/hide the clicked accordion item
        $this.closest(".faq").toggleClass("cc-open");
        $this.next().stop().slideToggle(settings.speed);
      },
    };
  })();

  accordion.init({ speed: 300, oneOpen: true });
});
